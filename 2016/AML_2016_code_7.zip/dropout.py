import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import sys



def compute_cost(theta,X,y, C):
    N = 0.5
    preds = np.dot(X, theta)
    J = (np.mean((y - preds)**2)) + ((1./N)*C * np.dot(theta,theta))
    return J


def get_grad(theta, X, y, alpha, C):
    N = X.shape[0]
    K = len(theta)
    gradVec = np.zeros(K)
    gradVec = gradVec + np.mean((y - np.dot(X, theta)).reshape(N,1) *  X, 0)
    return 2*gradVec


def stochasticgrad_theta(theta, y, X, alpha, C):
    N = 0.5
    dgrad = get_grad(theta, X, y, alpha, C)
    theta = theta + alpha * (dgrad - ((1./N)*C * theta))
    return theta

def main(theta,X,Y,C, alpha, sample_size, p): 
    itr = 0
    old_theta = theta
    D = X.shape[1] -1
    allcosts = []
    old_cost = compute_cost(theta,X,Y, C)
    theta_vec = []
    noChange = True
    while itr <= 3000:
        dropout = np.where(np.random.uniform(0,1,D) > p)[0]
        sample = np.random.choice(len(X),sample_size, replace=False)
        X1 = X[sample,:]
        y1 = Y[sample]
        if sum(dropout) != 0:
            X1[:, dropout] = 0
        y1 = Y[sample]
        theta = stochasticgrad_theta(old_theta, y1, X1, alpha, C)
        cost = compute_cost(theta,X,Y, C)
        allcosts.append(cost)
        old_theta = theta
        theta_vec.append(theta)
        old_cost = cost
        itr = itr + 1
    return [theta, allcosts, theta_vec]


if __name__ == '__main__':
    train = np.genfromtxt('train_7_2.csv', delimiter=",")
    valid = np.genfromtxt('valid_7_2.csv', delimiter=",")
    N = train.shape[0]
    D = train.shape[1] -1
    train_X, train_y = train[:,:-1], train[:,-1]
    valid_X, valid_y = valid[:,:-1], valid[:,-1]

    # This is the initialization that leads to proper overfitting
    theta = np.random.randn(D)
    # This reaches zero training error, but still works well for the validation
    # data as well
    #theta = np.zeros(D)

    probs = np.arange(0.05,1.05,0.05)
    lambdas = np.logspace(-3, 2, num=15)
    p_sols = []
    c_sols = []
    pt_sols = []
    ct_sols = []
    sample_size = 10
    alpha = 0.001
    print "probs"
    for p in probs:
        print p
        res = main(theta,train_X,train_y, 0., alpha, sample_size, p)
        tcost = compute_cost(res[0],train_X,train_y, 0.)
        cost = compute_cost(res[0],valid_X,valid_y, 0.)
        p_sols.append(cost)
        pt_sols.append(tcost)
    print "lambdas"
    for C in lambdas:
        print C
        res1 = main(theta,train_X,train_y, C, alpha, sample_size, 1.)
        tcost = compute_cost(res1[0],train_X,train_y, 0.)
        cost = compute_cost(res1[0],valid_X,valid_y, 0.)
        c_sols.append(cost)
        ct_sols.append(tcost)
    fig,axes=plt.subplots(figsize=(14,7), nrows=1, ncols=2,squeeze=False)
    axes[0][0].plot(probs,p_sols, "r-", label="valid")
    axes[0][0].plot(probs,pt_sols, "b-", label="train")
    axes[0][0].set_xlabel("Dropout probability")
    axes[0][0].set_ylabel("Error")
    axes[0][0].set_title("Dropout")
    legend = axes[0][0].legend(loc='upper right')
    axes[0][1].semilogx(lambdas, c_sols, "r-", label="valid")
    axes[0][1].semilogx(lambdas, ct_sols, "b-", label="train")
    axes[0][1].set_xlabel("Regularization parameter (log scale)")
    axes[0][1].set_ylabel("Error")
    axes[0][1].set_title("Ridge regression")
    legend = axes[0][1].legend(loc='upper right')
    with PdfPages('plot1.pdf') as pdf:
        pdf.savefig(fig)



    
